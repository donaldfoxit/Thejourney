![Thumbnail video tutorial](https://user-images.githubusercontent.com/6551176/230851974-f4d17c19-adb8-4a4c-bbea-c00443affd67.jpg)

[Demo](https://codesandbox.io/p/github/wass08/r3f-wawatmos-part-3)

[Video tutorial](https://youtu.be/18weM_oRVmE)

[Starter pack](https://github.com/wass08/r3f-wawatmos-starter)

[Part 1 Code](https://github.com/wass08/r3f-wawatmos-part1)

[Part 2 Code](https://github.com/wass08/r3f-wawatmos-part2)


### 3D Model credits

Airplane by Poly by Google [CC-BY](https://creativecommons.org/licenses/by/3.0/) via Poly Pizza (https://poly.pizza/m/8VysVKMXN2J)
